'use strict';

angular.module('{$ doc.ngModuleName $}', [])
  .value('{$ doc.serviceName $}', {$ doc.serviceValue | json $});
