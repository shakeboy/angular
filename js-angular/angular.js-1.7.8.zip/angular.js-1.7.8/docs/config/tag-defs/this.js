'use strict';

module.exports = {
  name: 'this'
};
